import java.util.HashMap;
import java.util.Map;

import java.util.ArrayList;

public class TableDrivenAgent extends Agent {
	private ArrayList<Perception> perceptions;
	private HashMap<ArrayList<Perception>, Action> table;

	
	public void preencher() {
		
	}
	
	
	
	

	
	 

}
